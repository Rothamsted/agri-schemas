"""
	(PyK)netMiner biotools - A set of tools used for bioinformatics
	
	@author: Marco Brandizi
"""
