"""
	(PyK)netMiner ETL tools
	
	A set of Python utilities and tools to build data extraction, 
	transformation and loading (ETL) pipelines.
	
	:author: Marco Brandizi 
"""