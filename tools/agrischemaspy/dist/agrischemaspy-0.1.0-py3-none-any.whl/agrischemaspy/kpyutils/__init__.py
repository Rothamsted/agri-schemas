"""
	kpyutils - The Knetminer Python Utils
	
	A set of general utilities for python programming, developed by the Knetminer Team
"""