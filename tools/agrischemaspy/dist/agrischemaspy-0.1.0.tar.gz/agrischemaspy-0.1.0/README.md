# AgriSchemas-Py

* TODO: write something.
* TODO: explain it's a transitional package, until we migrate to knetminer-etl.

